package com.example.travel_ex1;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SubActivity5 extends AppCompatActivity {

    EditText editText8;
    ArrayList<Book> items = new ArrayList<>();
    BookAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sub5);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editText8 = findViewById(R.id.editText8);
        adapter = new BookAdapter(this, R.layout.layout_item_book, items);
        ListView lv = findViewById(R.id.ListView1);
        lv.setAdapter(adapter);
    }

    public void onButton15Click(View view) { //검색
        items.clear();
        //네트워크 활성화 여부 확인
        ConnectivityManager manager = (ConnectivityManager)  getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = manager.getActiveNetworkInfo();

        if (info != null) {
            String keyword = editText8.getText().toString();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        searchBooks(keyword);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        } else {
            Toast.makeText(this, "네트워크를 먼저 연결하세요", Toast.LENGTH_SHORT).show();
        }
    }

    private void searchBooks(String keyword) throws JSONException{
        String clientId = "4NmlwIXp9rFJo8i85qsI"; //애플리케이션 클라이언트 아이디
        String clientSecret = "IKgqh_Tyq0"; //애플리케이션 클라이언트 시크릿


        String text = null;
        try {
            text = URLEncoder.encode(keyword, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("검색어 인코딩 실패",e);
        }


        String apiURL = "https://openapi.naver.com/v1/search/book.json?query=" + text;    // JSON 결과
        //String apiURL = "https://openapi.naver.com/v1/search/blog.xml?query="+ text; // XML 결과


        Map<String, String> requestHeaders = new HashMap<>();
        requestHeaders.put("X-Naver-Client-Id", clientId);
        requestHeaders.put("X-Naver-Client-Secret", clientSecret);
        String responseBody = get(apiURL,requestHeaders);
        System.out.println(responseBody);

        //코드추가
        try{
            JSONObject obj = new JSONObject(responseBody);
            JSONArray array = obj.getJSONArray("items");
            for (int i = 0; i< array.length(); i++){
                JSONObject objBook = (JSONObject) array.get(i);
                String title = objBook.getString("title");
                String image = objBook.getString("image");
                String author = objBook.getString("author");
                String publisher = objBook.getString("publisher");
                String pubdate = objBook.getString("pubdate");
                Book book = new Book(title, null, author, publisher, pubdate);
                getBookImage(book,image);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }

    private void getBookImage(Book book, String imageUrl) {
        Bitmap bmImage = null;
        try {
            URL url = new URL(imageUrl);
            InputStream is = url.openStream();
            bmImage = BitmapFactory.decodeStream(is);

        }catch (Exception e){
            e.printStackTrace();
        }

        book.setImage(bmImage);
        items.add(book);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                adapter.notifyDataSetChanged();

            }

        });

    }

    private String get(String apiURL, Map<String, String> requestHeaders) {
        HttpURLConnection con = connect(apiURL);
        try {
            con.setRequestMethod("GET");
            for(Map.Entry<String, String> header :requestHeaders.entrySet()) {
                con.setRequestProperty(header.getKey(), header.getValue());
            }


            int responseCode = con.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) { // 정상 호출
                return readBody(con.getInputStream());
            } else { // 오류 발생
                return readBody(con.getErrorStream());
            }
        } catch (IOException e) {
            throw new RuntimeException("API 요청과 응답 실패", e);
        } finally {
            con.disconnect();
        }
    }

    private static HttpURLConnection connect(String apiUrl){
        try {
            URL url = new URL(apiUrl);
            return (HttpURLConnection)url.openConnection();
        } catch (MalformedURLException e) {
            throw new RuntimeException("API URL이 잘못되었습니다. : " + apiUrl, e);
        } catch (IOException e) {
            throw new RuntimeException("연결이 실패했습니다. : " + apiUrl, e);
        }
    }


    private static String readBody(InputStream body){
        InputStreamReader streamReader = new InputStreamReader(body);

        try (BufferedReader lineReader = new BufferedReader(streamReader)) {
            StringBuilder responseBody = new StringBuilder();

            String line;
            while ((line = lineReader.readLine()) != null) {
                responseBody.append(line);
            }

            return responseBody.toString();
        } catch (IOException e) {
            throw new RuntimeException("API 응답을 읽는 데 실패했습니다.", e);
        }
    }
}