package com.example.travel_ex1;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SubActivity1 extends AppCompatActivity {

    private CalendarView calendarView;
    private Spinner spinner1;
    private EditText editText1, editText2;

    private TravelDBHelper dbHelper;
    private SQLiteDatabase sqldb;

    private String selectedDate; // 캘린더에서 선택한 날짜
    private String selectedDestination; // 스피너에서 선택한 여행지

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub1);

        // 초기화
        calendarView = findViewById(R.id.calendarView);
        spinner1 = findViewById(R.id.spinner1);
        editText1 = findViewById(R.id.editText1); // 메모 입력 필드


        dbHelper = new TravelDBHelper(this);

        // 캘린더에서 날짜 선택 이벤트 처리
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = year + "/" + (month + 1) + "/" + dayOfMonth;
        });

        // Spinner 설정
        String[] destinations = {"부산 서면", "해운대시장", "해운대 해수욕장", "광안리 해수욕장", "센텀시티",
                "자갈치·국제시장", "오시리아", "송정 해수욕장", "BIFF광장 일원", "낙동강생태공원", "부산역·초량",
                "달맞이고개", "전포카페거리", "오륙도·이기대 갈맷길", "동래온천", "을숙도", "일광 해수욕장",
                "송도 해수욕장", "가덕도", "청사포", "마린시티", "태종대", "민락수변공원", "해리단길", "부산시민공원",
                "기장해변·대변항", "다대포 해수욕장", "동백섬 일원", "부산민주공원", "수영사적공원·망미단길",
                "UN기념공원", "감천문화마을", "흰여울문화마을", "해동 용궁사", "죽성드림세트장", "암남공원",
                "임랑 해수욕장", "렛츠런파크", "황령산 봉수대", "장림포구", "국립해양박물관", "장산", "범어사", "아미산전망대"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, destinations);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedDestination = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedDestination = null;
            }
        });
    }

    public void onButton5Click(View view) { // 여행 추가하기
        if (selectedDate == null) {
            Toast.makeText(this, "날짜를 선택해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedDestination == null || selectedDestination.isEmpty()) {
            Toast.makeText(this, "여행지를 선택해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        String memo = editText1.getText().toString();
        if (memo.isEmpty()) {
            Toast.makeText(this, "메모를 입력해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        // 데이터베이스에 삽입
        sqldb = dbHelper.getWritableDatabase();
        String sql = "INSERT INTO Travel (date, destination, memo) VALUES ('" + selectedDate + "', '" + selectedDestination + "', '" + memo + "')";
        sqldb.execSQL(sql);
        Toast.makeText(this, "여행 일정이 추가되었습니다.", Toast.LENGTH_SHORT).show();

        editText1.setText(""); // 입력 필드 초기화
    }

    public void onButton6Click(View view) { // 데이터 불러오기 및 SubActivity2로 이동
        if (selectedDate == null) {
            Toast.makeText(this, "날짜를 선택해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        // 데이터베이스에서 해당 날짜의 데이터 조회
        sqldb = dbHelper.getReadableDatabase();
        Cursor cursor = sqldb.rawQuery("SELECT * FROM Travel WHERE date = ?", new String[]{selectedDate});

        if (cursor.moveToFirst()) { // 데이터가 있을 경우 처리
            String date = cursor.getString(cursor.getColumnIndex("date"));
            String destination = cursor.getString(cursor.getColumnIndex("destination"));
            String memo = cursor.getString(cursor.getColumnIndex("memo"));

            // SubActivity2로 데이터 전달
            Intent intent = new Intent(this, SubActivity2.class);
            intent.putExtra("date", date); // 날짜 전달
            intent.putExtra("destination", destination); // 여행지 전달
            intent.putExtra("memo", memo); // 메모 전달
            startActivity(intent);
        } else { // 데이터가 없을 경우 메시지 표시
            Toast.makeText(this, "해당 날짜에 저장된 일정이 없습니다.", Toast.LENGTH_SHORT).show();
        }

        cursor.close(); // Cursor 닫기
    }

    public void onButton7Click(View view) { // 홈 화면
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}