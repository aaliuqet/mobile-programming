package com.example.travel_ex1;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SubActivity4 extends AppCompatActivity {

    private EditText editText6, editText7;
    private ExpenseDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sub4);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new ExpenseDBHelper(this);

        editText6 = findViewById(R.id.editText6); // 날짜
        editText7 = findViewById(R.id.editText7); // 내역

        // EditText 설정
        editText7.setSingleLine(false);
        editText7.setLines(5);
        editText7.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        editText7.setVerticalScrollBarEnabled(true);
        editText7.setMovementMethod(new ScrollingMovementMethod());

        Intent intent = getIntent();
        String date = intent.getStringExtra("date");

        if (date != null) {
            editText6.setText(date); // 선택된 날짜 표시
            displayExpenseDetails(date); // 해당 날짜의 지출 내역 표시
        }
    }

    private void displayExpenseDetails(String date) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String sql = "SELECT category, SUM(amount) as total FROM Expense WHERE date = ? GROUP BY category";
        Cursor cursor = db.rawQuery(sql, new String[]{date});

        StringBuilder expenseDetails = new StringBuilder();

        while (cursor.moveToNext()) {
            String category = cursor.getString(cursor.getColumnIndexOrThrow("category"));
            int total = cursor.getInt(cursor.getColumnIndexOrThrow("total"));
            expenseDetails.append(category).append(": ").append(String.format("%,d원", total)).append("\n");
        }

        cursor.close();

        if (expenseDetails.length() == 0) {
            editText7.setText("지출 내역이 없습니다.");
        } else {
            editText7.setText(expenseDetails.toString().trim());
        }
    }

    public void onButton13Click(View view) { //뒤로가기
        Intent intent = new Intent(this, SubActivity3.class);
        startActivity(intent);
    }

    public void onButton14Click(View view) { //홈 화면
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}