package com.example.travel_ex1;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class SubActivity3 extends AppCompatActivity {

    private CalendarView calendarView2;
    private Spinner spinner2;
    private EditText editText5;
    private ExpenseDBHelper dbHelper;
    private String selectedDate;
    private String selectedCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sub3);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // DBHelper 초기화
        dbHelper = new ExpenseDBHelper(this);

        // View 초기화
        calendarView2 = findViewById(R.id.calendarView2);
        spinner2 = findViewById(R.id.spinner2);
        editText5 = findViewById(R.id.editText5);

        // 날짜 선택
        calendarView2.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = year + "/" + (month + 1) + "/" + dayOfMonth;
        });

        // Spinner 설정
        String[] expenseCategories = {"식비", "교통비", "숙박비", "기타"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, expenseCategories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter);

        // Spinner 선택 이벤트
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedCategory = parent.getItemAtPosition(position).toString(); // 올바른 호출
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedCategory = null; // 선택되지 않았을 때 처리
            }
        });

        // EditText에 천 단위 기호 자동 추가
        setupEditTextWithThousandSeparator(editText5);
    }

    private void setupEditTextWithThousandSeparator(EditText editText) {
        editText.addTextChangedListener(new TextWatcher() {
            private String currentText = "";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().equals(currentText)) {
                    editText.removeTextChangedListener(this); // 무한 루프 방지

                    String cleanString = s.toString().replaceAll("[,]", ""); // 기존 쉼표 제거
                    if (!cleanString.isEmpty()) {
                        try {
                            double parsed = Double.parseDouble(cleanString);
                            String formatted = new DecimalFormat("#,###").format(parsed); // 천 단위 포맷 적용
                            currentText = formatted;
                            editText.setText(formatted);
                            editText.setSelection(formatted.length()); // 커서 위치 조정
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                        }
                    }

                    editText.addTextChangedListener(this); // 리스너 다시 추가
                }
            }
        });
    }

    public void onButton10Click(View view) { // 추가하기
        if (selectedDate == null) {
            Toast.makeText(this, "날짜를 선택해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedCategory == null || selectedCategory.isEmpty()) {
            Toast.makeText(this, "카테고리를 선택해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        String amountText = editText5.getText().toString().replaceAll("[,]", "");
        if (amountText.isEmpty()) {
            Toast.makeText(this, "금액을 입력해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        int amount;
        try {
            amount = Integer.parseInt(amountText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "올바른 금액을 입력해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // 동일한 날짜와 카테고리가 이미 존재하는지 확인
        String query = "SELECT amount FROM Expense WHERE date = ? AND category = ?";
        Cursor cursor = db.rawQuery(query, new String[]{selectedDate, selectedCategory});

        if (cursor.moveToFirst()) {
            // 존재하면 금액 업데이트 (합산)
            int existingAmount = cursor.getInt(cursor.getColumnIndexOrThrow("amount"));
            int newAmount = existingAmount + amount;

            String updateSql = "UPDATE Expense SET amount = ? WHERE date = ? AND category = ?";
            db.execSQL(updateSql, new Object[]{newAmount, selectedDate, selectedCategory});
        } else {
            // 존재하지 않으면 새로 삽입
            String insertSql = "INSERT INTO Expense (date, category, amount) VALUES (?, ?, ?)";
            db.execSQL(insertSql, new Object[]{selectedDate, selectedCategory, amount});
        }

        cursor.close();

        Toast.makeText(this, "지출 내역이 추가되었습니다.", Toast.LENGTH_SHORT).show();
        editText5.setText(""); // 금액 입력 초기화
    }

    public void onButton11Click(View view) { // 불러오기 버튼
        if (selectedDate == null) {
            Toast.makeText(this, "날짜를 선택해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String sql = "SELECT category, SUM(amount) as total FROM Expense WHERE date = ? GROUP BY category";
        Cursor cursor = db.rawQuery(sql, new String[]{selectedDate});

        if (cursor.getCount() > 0) {
            StringBuilder expenseDetails = new StringBuilder();

            while (cursor.moveToNext()) {
                String category = cursor.getString(cursor.getColumnIndexOrThrow("category"));
                int total = cursor.getInt(cursor.getColumnIndexOrThrow("total"));
                expenseDetails.append(category).append(": ").append(String.format("%,d원", total)).append("\n");
            }

            cursor.close();

            // SubActivity4로 데이터 전달
            Intent intent = new Intent(this, SubActivity4.class);
            intent.putExtra("date", selectedDate); // 선택한 날짜
            intent.putExtra("details", expenseDetails.toString().trim()); // 지출 내역
            startActivity(intent);
        } else {
            cursor.close();
            Toast.makeText(this, "해당 날짜의 지출 내역이 없습니다.", Toast.LENGTH_SHORT).show();
        }
    }

    public void onButton12Click(View view) { // 뒤로가기
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
