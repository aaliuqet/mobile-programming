package com.example.travel_ex1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void onButton1Click(View view) { //내 여행 플랜
        Intent intent = new Intent(this, SubActivity1.class);
        startActivity(intent); // SubActivity1으로 이동
    }

    public void onButton3Click(View view) { // 여행 지갑
        Intent intent = new Intent(this, SubActivity3.class);
        startActivity(intent); // SubActivity3으로 이동
    }

    public void onButton4Click(View view) { //주변 둘러보기
        Intent intent = new Intent(this, SubActivity5.class);
        startActivity(intent); //// SubActivity5으로 이동
    }
}