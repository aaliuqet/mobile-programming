package com.example.travel_ex1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class SubActivity2 extends AppCompatActivity {

    private EditText editText2, editText3, editText4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub2);

        // EditText 초기화
        editText2 = findViewById(R.id.editText2); // 날짜
        editText3 = findViewById(R.id.editText3); // 여행지
        editText4 = findViewById(R.id.editText4); // 메모

        // SubActivity1에서 전달된 데이터 받기
        Intent intent = getIntent();
        String date = intent.getStringExtra("date"); // 전달받은 날짜
        String destination = intent.getStringExtra("destination"); // 전달받은 여행지
        String memo = intent.getStringExtra("memo"); // 전달받은 메모

        // EditText에 데이터 설정
        editText2.setText(date);
        editText3.setText(destination);
        editText4.setText(memo);
    }

    public void onButton8Click(View view) { // 뒤로가기
        Intent intent = new Intent(this, SubActivity1.class); // SubActivity1으로 이동
        startActivity(intent);
    }

    public void onButton9Click(View view) { // 홈 화면
        Intent intent = new Intent(this, MainActivity.class); // MainActivity로 이동
        startActivity(intent);
    }
}
