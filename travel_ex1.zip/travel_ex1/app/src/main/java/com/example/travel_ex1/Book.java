package com.example.travel_ex1;

import android.graphics.Bitmap;

public class Book {
    private String title;
    private Bitmap image;
    private String author;
    private String publisher;
    private String pubdate;

    public Book(String title, Bitmap image, String author, String publisher, String pubdate) {
        this.title = title;
        this.image = image;
        this.author = author;
        this.publisher = publisher;
        this.pubdate = pubdate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getPubdate() {
        return pubdate;
    }

    public void setPubdate(String pubdate) {
        this.pubdate = pubdate;
    }
}